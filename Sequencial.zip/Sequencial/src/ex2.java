import java.util.Scanner;
public class ex2 {

	

	public static void main(String[] args) {
		int num;
		Scanner entrada = new Scanner(System.in);
		System.out.println("Informe um numero(inteiro):");
		num = entrada.nextInt();
		System.out.println("Numero Informado : "+ num);
		

	}

}
